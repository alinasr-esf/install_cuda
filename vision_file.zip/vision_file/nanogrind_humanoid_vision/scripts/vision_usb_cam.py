#! /usr/bin/env python3
import rospy
from sensor_msgs.msg import Image
from std_msgs.msg import Header
from detection_msgs.msg import BoundingBox, BoundingBoxes
from cv_bridge import CvBridge, CvBridgeError

import random
from yolov5.utils.torch_utils import select_device, time_sync
from yolov5.utils.general import (check_img_size, non_max_suppression,  scale_coords, set_logging)
from yolov5.utils.datasets import letterbox
from yolov5.models.experimental import attempt_load
import torch.backends.cudnn as cudnn
import torch

import yaml
import numpy as np
import cv2

bridge = CvBridge()
header = Header()
pub_boundingbox = rospy.Publisher('Vision/boundingbox', BoundingBoxes, queue_size=10)

def camera_callback(data):
    global original_image, key
    try:
        original_image = bridge.imgmsg_to_cv2(
            data,
           "bgr8"
        )  
        header = data.header
    except CvBridgeError as e:
        print(e)

def depth_camera_callback(data):
    global orginal_depth_image
    try:
        orginal_depth_image = bridge.imgmsg_to_cv2(
            data,
            data.encoding
        ) 
    except CvBridgeError as e:
        print(e)

class YoloV5:
    def __init__(self, yolov5_yaml_path='./config/bottle_cup.yaml'):
        with open(yolov5_yaml_path, 'r', encoding='utf-8') as f:
            self.yolov5 = yaml.load(f.read(), Loader=yaml.SafeLoader)
        self.colors = [[np.random.randint(0, 255) for _ in range(
            3)] for class_id in range(self.yolov5['class_num'])]
        self.init_model()

    @torch.no_grad()
    def init_model(self):
        set_logging()
        device = select_device(self.yolov5['device'])
        is_half = device.type != 'cpu'
        model = attempt_load(
            self.yolov5['weight'], map_location=device) 
        input_size = check_img_size(
            self.yolov5['input_size'], s=model.stride.max()) 
        if is_half:
            model.half()  
        cudnn.benchmark = True  
        img_torch = torch.zeros(
            (1, 3, self.yolov5['input_size'], self.yolov5['input_size']), device=device)
        _ = model(img_torch.half()
                  if is_half else img) if device.type != 'cpu' else None
        self.is_half = is_half  
        self.device = device  
        self.model = model  
        self.img_torch = img_torch

    def preprocessing(self, img):
        img_resize = letterbox(img, new_shape=(
            self.yolov5['input_size'], self.yolov5['input_size']), auto=False)[0]
        img_arr = np.stack([img_resize], 0)
        img_arr = img_arr[:, :, :, ::-1].transpose(0, 3, 1, 2)
        img_arr = np.ascontiguousarray(img_arr)
        return img_arr

    @torch.no_grad()
    def detect(self, img, canvas=None, view_img=True):
        global header
        img_resize = self.preprocessing(img) 
        self.img_torch = torch.from_numpy(img_resize).to(self.device) 
        self.img_torch = self.img_torch.half(
        ) if self.is_half else self.img_torch.float() 
        self.img_torch /= 255.0 
        if self.img_torch.ndimension() == 3:
            self.img_torch = self.img_torch.unsqueeze(0)
        t1 = time_sync()
        pred = self.model(self.img_torch, augment=False)[0]
        pred = non_max_suppression(pred, self.yolov5['threshold']['confidence'],
                                   self.yolov5['threshold']['iou'], classes=None, agnostic=False)
        t2 = time_sync()
        det = pred[0]
        gain_whwh = torch.tensor(img.shape)[[1, 0, 1, 0]]  

        if view_img and canvas is None:
            canvas = np.copy(img)
        xyxy_list = []
        conf_list = []
        class_id_list = []
        bounding_boxes = BoundingBoxes()
        bounding_boxes.header = header
        bounding_boxes.image_header = header
        if det is not None and len(det):
            det[:, :4] = scale_coords(
                img_resize.shape[2:], det[:, :4], img.shape).round()
            for *xyxy, conf, class_id in reversed(det):
                class_id = int(class_id)
                xyxy_list.append(xyxy)
                conf_list.append(conf)
                class_id_list.append(class_id)
                bounding_box = BoundingBox()
                bounding_box.Class = self.yolov5['class_name'][class_id]
                bounding_box.probability = conf 
                bounding_box.xmin = int(xyxy[0])
                bounding_box.ymin = int(xyxy[1])
                bounding_box.xmax = int(xyxy[2])
                bounding_box.ymax = int(xyxy[3])
                bounding_boxes.bounding_boxes.append(bounding_box)
                if view_img:
                    label = '%s %.2f' % (
                        self.yolov5['class_name'][class_id], conf)
                    self.plot_one_box(
                        xyxy, canvas, label=label, color=self.colors[class_id], line_thickness=3)
            pub_boundingbox.publish(bounding_boxes)
        return canvas, class_id_list, xyxy_list, conf_list

    def plot_one_box(self, x, img, color=None, label=None, line_thickness=None):
        tl = line_thickness or round(
            0.002 * (img.shape[0] + img.shape[1]) / 2) + 1  
        color = color or [random.randint(0, 255) for _ in range(3)]
        c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
        cv2.rectangle(img, c1, c2, color, thickness=tl, lineType=cv2.LINE_AA)
        if label:
            tf = max(tl - 1, 1) 
            t_size = cv2.getTextSize(
                label, 0, fontScale=tl / 3, thickness=tf)[0]
            c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
            cv2.rectangle(img, c1, c2, color, -1, cv2.LINE_AA)  
            cv2.putText(img, label, (c1[0], c1[1] - 2), 0, tl / 3,
                       [225, 255, 255], thickness=tf, lineType=cv2.LINE_AA)

def main():
    global original_image, orginal_depth_image#, intr
    print('[INFO] Running usb_cam file')
    rospy.init_node("camera_feed_node", anonymous=True)
    image_sub = rospy.Subscriber("/usb_cam/image_raw" ,Image ,camera_callback)
    pub_image = rospy.Publisher('Vision/image/detected', Image, queue_size=10)
    model = YoloV5(yolov5_yaml_path='./src/nanogrind_humanoid_vision/config/bottle_cup.yaml')
    
    try:
        while True:
            color_image = np.asanyarray(original_image)
            if not original_image.any():
                continue
            canvas, class_id_list, xyxy_list, conf_list = model.detect(
                color_image)
            pub_image.publish(bridge.cv2_to_imgmsg(canvas))     
            cv2.imshow('color',canvas)
            key = cv2.waitKey(30)
            if key & 0xFF == ord('q') or key == 27:
                cv2.destroyAllWindows()
                break
    except KeyboardInterrupt:
        print("Shutting down")

if __name__ == '__main__':

    main()